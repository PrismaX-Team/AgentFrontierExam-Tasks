"""Coordination geometry files."""
